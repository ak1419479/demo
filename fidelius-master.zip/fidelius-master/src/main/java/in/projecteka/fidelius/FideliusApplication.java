package in.projecteka.fidelius;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FideliusApplication {

    public static void main(String[] args) {
        SpringApplication.run(FideliusApplication.class, args);
    }

}
